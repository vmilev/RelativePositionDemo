﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Panels
{
    public enum HorizontalPositionAlignment
    {
        Left,
        Center,
        Right
    }
}
