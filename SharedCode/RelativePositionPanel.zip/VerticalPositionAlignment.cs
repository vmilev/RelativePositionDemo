﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Panels
{
    public enum VerticalPositionAlignment
    {
        Top,
        Center,
        Bottom
    }
}
